package com.mvc.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.mvc.dao.CustomerOperationsImpl;
import com.mvc.model.LoginForm;

@Service
public class UserAuthorizationService {
	@Autowired
	private CustomerOperationsImpl customerOperations;
	public String userAuth(LoginForm loginForm) throws SQLException {
		customerOperations.getUsers(loginForm);
		return "true";
	}

}
