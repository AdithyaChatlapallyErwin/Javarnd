package com.mvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity(name ="CustomerDetails")
@javax.persistence.Table(name = "CustomerDetails")
public class CustomerDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String custId;
	private String customerName;
	private String customerPhNo;
	private String customerLicenseNo;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerPhNo() {
		return customerPhNo;
	}
	public void setCustomerPhNo(String customerPhNo) {
		this.customerPhNo = customerPhNo;
	}
	public String getCustomerLicenseNo() {
		return customerLicenseNo;
	}
	public void setCustomerLicenseNo(String customerLicenseNo) {
		this.customerLicenseNo = customerLicenseNo;
	}
	
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
		

}
