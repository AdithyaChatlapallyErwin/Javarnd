package com.mvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

//import org.hibernate.annotations.Table;
import org.hibernate.validator.constraints.Email;

import jakarta.validation.constraints.NotNull;

@Entity(name = "customer")
@javax.persistence.Table(name = "customer")
public class RegistrationForm {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@javax.validation.constraints.NotNull(message = "is required")
private String name;
	@javax.validation.constraints.NotNull
	@javax.validation.constraints.Email
private String email;
	@javax.validation.constraints.NotNull
	@Size(min = 10,max = 10)
private String phoneNum;
	@javax.validation.constraints.NotNull
private String password;
public String getPassword() {
	return password;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public void setPassword(String password) {
	this.password = password;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhoneNum() {
	return phoneNum;
}
public void setPhoneNum(String phoneNum) {
	this.phoneNum = phoneNum;
}

}
