package com.mvc.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.mvc.model.CustomerDetails;
import com.mvc.model.RegistrationForm;
@Repository
public class CompanyOperationsImpl implements CompanyOperations{

	@Override
	public String addCustomer(CustomerDetails customerDetails) {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(CustomerDetails.class).
		configure("com/mvc/config/hibernate.cfg.xml");

//				
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();
		System.out.println("reg name===="+customerDetails.getCustomerName());
		try {
			session.beginTransaction();
			session.save(customerDetails);

			session.getTransaction().commit();
			System.out.println("Done");
		}finally {
			session.close();
			sessionFactory.close();
		}
		
		return "true";

		
	}

	@Override
	public String editCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

}
