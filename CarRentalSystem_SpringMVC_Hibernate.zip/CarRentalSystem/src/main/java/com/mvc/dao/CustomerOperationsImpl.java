package com.mvc.dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mvc.model.LoginForm;
import com.mvc.model.RegistrationForm;
@Repository
public class CustomerOperationsImpl implements CustomerOperations {

	@Override
	public String saveCustomer(RegistrationForm reg) throws SQLException {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(RegistrationForm.class).
		configure("com/mvc/config/hibernate.cfg.xml");

//				
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();
		System.out.println("reg name===="+reg.getName());
		try {
			session.beginTransaction();
			session.save(reg);

			session.getTransaction().commit();
			System.out.println("Done");
		}finally {
			session.close();
			sessionFactory.close();
		}
		
		return "true";
	}

	@Override
	public String login() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String registrationConfirmation() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String reserveCar() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String carIssued() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUsers(LoginForm loginForm) throws SQLException {
		try {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(LoginForm.class).
		configure("com/mvc/config/hibernate.cfg.xml");

//				
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		List<RegistrationForm> list = sessionFactory.openSession().createQuery("From RegistrationForm where name=? and password=?").setParameter(0, loginForm.getUserName()).setParameter(1, loginForm.getPassword()).list();
		System.out.println("======list "+list.size());
		if(list.size()>0) {
			System.out.println("======list "+list.size());
			return "true";
			
		}
		else 
			return "false";
		}catch(Exception ex) {
			ex.printStackTrace();
			return "false";
		}
		
		//Session session = sessionFactory.openSession();
		//System.out.println("reg name===="+reg.getName());
	
		
		
		
	}

		
		
	


}
