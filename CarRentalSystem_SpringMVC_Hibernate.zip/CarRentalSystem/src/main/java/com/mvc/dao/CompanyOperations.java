package com.mvc.dao;

import com.mvc.model.CustomerDetails;

public interface CompanyOperations {
public String addCustomer(CustomerDetails customerDetails);
public String editCustomer();
public String deleteCustomer();
}
