package com.mvc.dao;

import java.sql.SQLException;

import com.mvc.model.LoginForm;
import com.mvc.model.RegistrationForm;

public interface CustomerOperations {
public String saveCustomer(RegistrationForm reg) throws SQLException;
public String login() throws SQLException;
public String registrationConfirmation()throws SQLException;
public String reserveCar()throws SQLException;
public String carIssued()throws SQLException;
public String getUsers(LoginForm loginForm)throws SQLException;

}
