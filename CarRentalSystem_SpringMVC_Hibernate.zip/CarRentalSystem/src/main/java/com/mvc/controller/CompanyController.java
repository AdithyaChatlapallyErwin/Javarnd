package com.mvc.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mvc.dao.CompanyOperationsImpl;
import com.mvc.model.CustomerDetails;
import com.mvc.model.RegistrationForm;

@Controller
public class CompanyController {
	@Autowired
	private CompanyOperationsImpl companyOperationsImpl;

	@GetMapping("companyPage")
	public String companyPage(Model model) {
		//model.addAttribute("register", new RegistrationForm());
		return "companyPage";
	}
	@RequestMapping(value = "/addCustomer", method = RequestMethod.GET)
	public String addCustomer(Model model,@ModelAttribute("customerDetails") CustomerDetails customerDetails,BindingResult br) {
		model.addAttribute("customerDetails", new CustomerDetails());
		System.out.println(customerDetails.getCustomerLicenseNo());
		if(br.hasErrors()) {
			return "addCustomer";
		}else {
			companyOperationsImpl.addCustomer(customerDetails);
		}
		return "addCustomer";
	}
	@GetMapping("editCustomer")
	public String editCustomer(Model model) {
		//model.addAttribute("register", new RegistrationForm());
		return "editCustomer";
	}
	@GetMapping("deleteCustomer")
	public String deleteCustomer(Model model) {
		//model.addAttribute("register", new RegistrationForm());
		return "deleteCustomer";
	}
	@GetMapping("addCar")
	public String addCar(Model model) {
		//model.addAttribute("register", new RegistrationForm());
		return "addCar";
	}
	@GetMapping("editCar")
	public String editCar(Model model) {
		//model.addAttribute("register", new RegistrationForm());
		return "editCar";
	}
	@GetMapping("deleteCar")
	public String deleteCar(Model model) {
		//model.addAttribute("register", new RegistrationForm());
		return "deleteCar";
	}
	@GetMapping("availableCars")
	public String availableCars(Model model) {
		//model.addAttribute("register", new RegistrationForm());
		return "availableCars";
	}
	@GetMapping("transactionReports")
	public String transactionReports(Model model) {
		//model.addAttribute("register", new RegistrationForm());
		return "transactionReports";
	}
	@GetMapping("getCustomersList")
	public String getCustomersList(Model model) {
		//model.addAttribute("register", new RegistrationForm());
		return "getCustomersList";
	}
	
}
