package com.mvc.controller;

import java.sql.SQLException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mvc.dao.CustomerOperationsImpl;
import com.mvc.model.LoginForm;
import com.mvc.model.RegistrationForm;
import com.mvc.service.UserAuthorizationService;

@Controller
@Validated
public class CustomerController {
	@Autowired
	private CustomerOperationsImpl customerOperations;
	@Autowired
	private UserAuthorizationService userAuth;

	// @RequestMapping("Form")
	@GetMapping("Form")
	public String newRegisterForm(Model model) {
		model.addAttribute("register", new RegistrationForm());
		return "NewRegisterForm";
	}

	@GetMapping("customerPage")
	public String customerPage() {
		return "CustomerPage";
	}

	// @RequestMapping("registrationstatus")
	@PostMapping(path = "/registrationstatus")
	public String registrationStatus(@Valid @ModelAttribute("register") RegistrationForm register, BindingResult br,
			Model model) throws Exception {
		System.out.println("containes error:=========" + br.hasErrors());
		System.out.println("containes error:=========" + register.getName());
		if (br.hasErrors()) {
			System.out.println(br.hasErrors());
			return "NewRegisterForm";
		} else {
			String status = customerOperations.saveCustomer(register);
			System.out.println("===status  " + status);
			model.addAttribute("status", status);
			return "RegistrationStatus";
		}

	}
	@GetMapping("login")
	public String loginPage(Model model, @ModelAttribute("loginForm") LoginForm loginForm, BindingResult br) {
	    System.out.println(loginForm.getUserName());
	    model.addAttribute("loginForm", new LoginForm());
		return "LoginPage";
	}
	@PostMapping("userAuthorization")
	public String userAuthorization(Model model, @ModelAttribute("loginForm") LoginForm loginForm, BindingResult br) throws SQLException {
		System.out.println(loginForm.getUserName());
		userAuth.userAuth(loginForm);
		return "UserAuthorizationResult";
	}
	

}
