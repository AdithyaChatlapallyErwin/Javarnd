package com.javarnd.controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.javarnd.model.Address;
import com.javarnd.model.Employee;
@Configuration
public class SpringConfig{
	@Bean
	public Employee employee() {
		return new Employee();
	}
	@Bean
	public Address addr() {
		return new Address();
	}
}