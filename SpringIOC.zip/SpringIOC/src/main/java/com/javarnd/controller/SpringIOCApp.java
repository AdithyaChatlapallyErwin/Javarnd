package com.javarnd.controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.javarnd.model.Address;
import com.javarnd.model.Employee;

public class SpringIOCApp{
	public static void main(String [] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		Employee emp = (Employee) context.getBean("employee");
		Address addr = (Address) context.getBean("addr");
		addr.setHNo(1);
		addr.setCity("New York");
		addr.setState("California");
		emp.setEmpId(1);
		emp.setAddr(addr);;
		System.out.println(emp.getEmpId());
		System.out.println(emp.getAddr());
	}
	
}