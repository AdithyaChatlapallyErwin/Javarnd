package com.javarnd.model;

public class Address {
private int hNo;
public int gethNo() {
	return hNo;
}
public void sethNo(int hNo) {
	this.hNo = hNo;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
private String city;
private String state;
@Override
public String toString() {
	return "Address [hNo=" + hNo + ", city=" + city + ", state=" + state + "]";
}
}
