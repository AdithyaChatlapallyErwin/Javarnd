package com.javarnd.model;

import org.springframework.context.annotation.Configuration;

@Configuration
public class Employee {
private int empId;
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = 1;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public Address getAddr() {
	return addr;
}
public void setAddr(Address addr) {
	this.addr = addr;
}
private String employeeName;
private Address addr;
}
